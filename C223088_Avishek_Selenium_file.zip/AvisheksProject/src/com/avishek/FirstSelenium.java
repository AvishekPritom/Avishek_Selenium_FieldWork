package com.avishek;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FirstSelenium {

    public static void main(String[] args) {

        // Create browser driver
        WebDriver driver = new ChromeDriver();

        // Open website
        driver.get(
            "https://www.ryans.com/"
        );

        // Get website title
        String title = driver.getTitle();

        System.out.println("Website Title: " + title);
        
        WebElement Searchbox = driver.findElement(By.name("search"));
        Searchbox.sendKeys("Tablet");
        driver.navigate().to("https://www.ryans.com/honor-pad-x7-wi-fi-4gb-ram-128gb-rom-tablet");
        driver.navigate().to("https://www.ryans.com/cart");
        driver.findElement(By.className("details-cart-btn")).click();		
        System.out.println("Successfully clicked on Add to Cart!");
        
        WebElement cartQuantityElement = driver.findElement(By.className("cart-item-count")); 
        String cartQuantityText = cartQuantityElement.getText();

        if (cartQuantityText.equals("1")) {
            System.out.println("Verification Passed");
        } else {
            System.out.println("Verification Failed: Expected quantity 1, but found: " + cartQuantityText);
        }

        //		driver.navigate().to(title)
        driver.manage().window().maximize();

         //Maximize browser
        //driver.manage().timeouts().getImplicitWaitTimeout();

        // Close browser
        driver.quit();
    }
}